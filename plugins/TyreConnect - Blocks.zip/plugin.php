<?php
/**
 * Plugin Name: TyreConnect Gutenblocks
 * Description: A plugin to register blocks for gutenberg
 * Version: 1.0.0
 * License: GPL2+
 * License URI: https://www.gnu.org/licenses/gpl-2.0.txt
 *
 * @package CGB
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Block Initializer.
 */
require_once plugin_dir_path( __FILE__ ) . 'build/tc-about-us/src/init.php';
require_once plugin_dir_path( __FILE__ ) . 'build/tc-dealership/src/init.php';
require_once plugin_dir_path( __FILE__ ) . 'build/tc-card/src/init.php';
require_once plugin_dir_path( __FILE__ ) . 'build/tc-contact-us/src/init.php';
require_once plugin_dir_path( __FILE__ ) . 'build/tc-cta-section/src/init.php';
require_once plugin_dir_path( __FILE__ ) . 'build/tc-hero/src/init.php';
require_once plugin_dir_path( __FILE__ ) . 'build/tc-marketing-section/src/init.php';
require_once plugin_dir_path( __FILE__ ) . 'build/tc-medium-articles/src/init.php';
require_once plugin_dir_path( __FILE__ ) . 'build/tc-section/src/init.php';
// require_once plugin_dir_path( __FILE__ ) . 'build/tc-testimonials/src/init.php';
require_once plugin_dir_path( __FILE__ ) . 'build/tc-tyre-brands/src/init.php';
require_once plugin_dir_path( __FILE__ ) . 'build/ordered-list/src/init.php';
